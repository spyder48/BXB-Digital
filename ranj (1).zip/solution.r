#setwd("C:/Users/Ravish Ranjan/Desktop/ranj")
#install.packages("forecast")
#install.packages("tseries")
library(forecast)
library(tseries)

#Reading Data
data = read.csv("Train_data.csv")

# Feature engineering - New feature - Average number of issues in month
data$avg_issues = data$IssuesInMonth/data$BusinessDaysInMonth
ret = log(data$avg_issues[2:nrow(data)]/data$avg_issues[1:(nrow(data)-1)])

# We split 120 datapoints as 108 training set data and 12 test set data
ret = ret[-c(108,109,110,111,112,113,114,115,116,117,118,119)]
ret1 = log(data$avg_issues[109:nrow(data)]/data$avg_issues[108:(nrow(data)-1)])

# Add 2 more columns in dataframe for predicted data
data$pred_issues = data$IssuesInMonth
data$avg_issues2 = data$avg_issues


# We apply Time Series Modelling mechanism
# Augmented Dickey Fuller Test to check for stationarity of time series
# Augmented Dickey Fuller test, alpha = 0.05
# H0 => Non-Stationary
# H1 => Stationary
t2 = adf.test(ret, k=10)
t2
# p-value < 0.01    => H0 rejected => Stationary

# acf and pacf plots
acf(ret)
pacf(ret)

# Select best ARIMA model based on AIC criteria
model1 = auto.arima(ret, trace=T ) # best model => ARIMA(2, 0, 2) with 0 mean
model1 # Gives coefficients of ARIMA equation

# Forecasting for test data
pred_ret = forecast(model1, h = 12, level = 0.99) # Confidence interval - 99%
pred_ret$mean # gives forecast

# Plot of actual vs fitted model
plot(ret, type = 'l')
lines(fitted(model1), col = "red")

# Check validity of the model
# Ljung Box Test, alpha = 0.1
# H0 => errors are white noise
# H1 => erros are not White noise
box = Box.test(model1$residuals, type = "Ljung-Box")
box
# p value = 0.1279 => Fail to reject Ho => errors are white noise : Model is valid

# Calculated Predicted Number of Issues in Month from Predicted Average Issues
i=0
for(i in (1:12)){
  data$avg_issues2[i+108] = data$avg_issues2[108+i-1]*exp(pred_ret$mean[i])
  data$pred_issues[i+108] = data$avg_issues2[i+108]*data$BusinessDaysInMonth[i+108]
}

# Check model accuracy on test data - MAPE
#install.packages("MLmetrics")
library(MLmetrics)
accuracy = accuracy(data$pred_issues[c(109,110,111,112,113,114,115,116,117,118,119,120)], data$IssuesInMonth[c(109,110,111,112,113,114,115,116,117,118,119,120)] )
# MAPE = 7.44% 

# Forecasting for Problem Statement 

#Reading Data
data = read.csv("Train_data.csv")
data1 = read.csv("Test_data.csv")
data1 = data1[-c(1,3,5,7,9,11),] # Data cleaning

# Feature engineering - New feature - Average number of issues in month
data$avg_issues = data$IssuesInMonth/data$BusinessDaysInMonth
ret = log(data$avg_issues[2:nrow(data)]/data$avg_issues[1:(nrow(data)-1)])

# We apply Time Series Modelling mechanism
# Augmented Dickey Fuller Test to check for stationarity of time series
# Augmented Dickey Fuller test, alpha = 0.05
# H0 => Non-Stationary
# H1 => Stationary
t2 = adf.test(ret, k=10)
t2
# p-value = 0.01    => H0 rejected => Stationary

# acf and pacf plots
acf(ret)
pacf(ret)

# Select best ARIMA model based on AIC criteria
model1 = auto.arima(ret, trace=T ) # best model => ARIMA(2, 0, 2) with 0 mean
model1 # Gives coefficients of ARIMA equation

# Forecasting for test data
pred_ret = forecast(model1, h = 6, level = 0.99) # Confidence interval - 99%
pred_ret$mean # gives forecast

# Plot of actual vs fitted model
plot(ret, type = 'l')
lines(fitted(model1), col = "red")

# Check validity of the model
# Ljung Box Test, alpha = 0.1
# H0 => errors are white noise
# H1 => erros are not White noise
box = Box.test(model1$residuals, type = "Ljung-Box")
box
# p value = 0.1128 => Fail to reject Ho => errors are white noise : Model is valid

# Calculated Predicted Number of Issues in Month from Predicted Average Issues
i=1
data1$avg_issues2 = pred_ret$mean 
data1$IssuesInMonth = pred_ret$mean 

data1$avg_issues2[i] = data$avg_issues[120]*exp(pred_ret$mean[i])
data1$IssuesInMonth[i] = data1$avg_issues2[i]*data1$BusinessDaysInMonth[i]

for(i in (2:6)){
  data1$avg_issues2[i] = data1$avg_issues2[i-1]*exp(pred_ret$mean[i])
  data1$IssuesInMonth[i] = data1$avg_issues2[i]*data1$BusinessDaysInMonth[i]
}
data1 = data1[,-c(2,3)]

# Import predicted data in 1 file
write.csv(data1, file = "Final Submission.csv", row.names = FALSE)
